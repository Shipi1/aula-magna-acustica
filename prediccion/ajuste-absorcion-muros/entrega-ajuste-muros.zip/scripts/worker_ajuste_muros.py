"""Usar con Python de I-Simpa: separa muros o lee resultados nativos."""
from pathlib import Path
import sys,json
sys.path.insert(0,r'C:/Program Files/I-SIMPA')
import libsimpa as L
ROOT=Path(__file__).resolve().parents[2]
BASE=ROOT/'prediccion/ajuste-absorcion-muros'
SOURCE=ROOT/'prediccion/variantes-estado-actual/B_cortinas_y_paneles'
if sys.argv[1]=='mesh':
    g=json.loads((SOURCE/'geometria.json').read_text(encoding='utf8'))
    model=L.ioModel();assert L.CformatBIN().ImportBIN(model,str(SOURCE/'mesh.cbin'))
    assert len(model.faces)==len(g['faces'])
    selected=[]
    for i,f in enumerate(g['faces']):
        if f['material'] in ['muros','laterales_altos','fondo_alto']:
            face=model.faces[i];assert face.idMat==107
            face.idMat=115;model.faces[i]=face;selected.append(i)
    assert L.CformatBIN().ExportBIN(str(BASE/'mesh.cbin'),model)
    after=L.ioModel();assert L.CformatBIN().ImportBIN(after,str(BASE/'mesh.cbin'))
    original=L.ioModel();assert L.CformatBIN().ImportBIN(original,str(SOURCE/'mesh.cbin'))
    for i in range(len(original.vertices)):
        assert all(original.vertices[i][k]==after.vertices[i][k] for k in range(3))
    for i in range(len(original.faces)):
        a,b=original.faces[i],after.faces[i]
        assert (a.a,a.b,a.c,a.idRs,a.idEn)==(b.a,b.b,b.c,b.idRs,b.idEn)
        assert b.idMat==(115 if i in set(selected) else a.idMat)
    (BASE/'separacion-muros.json').write_text(json.dumps({'material_nuevo_id':115,'grupos':['05_muros','10_laterales_altos','11_fondo_alto'],'caras':len(selected),'geometria_identica':True}),encoding='utf8')
    print('Muros separados: '+str(len(selected))+' caras; geometría idéntica.')
elif sys.argv[1]=='read':
    out=Path(sys.argv[2]);result={'receptores':{}}
    for i in range(1,10):
        name='P'+str(i);reader=L.Gabe_rw()
        assert reader.Load(str(out/'Punctual receivers'/name/'Sound level.recp'))
        columns=reader.ToList();assert len(columns[0])==4001
        result['receptores'][name]={c[0]:c[1:] for c in columns[1:]}
    reader=L.Gabe_rw();assert reader.Load(str(out/'SPPS particle statistics.gabe'))
    result['estadisticas']=reader.ToList()
    (out/'resultados-lineales.json').write_text(json.dumps(result,ensure_ascii=False),encoding='utf8')
