"""Proyecto independiente con material efectivo, resultados y contraste con REW."""
from pathlib import Path
import json,zipfile,copy,hashlib,xml.etree.ElementTree as ET
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import NullFormatter
ROOT=Path(__file__).resolve().parents[2];BASE=ROOT/'prediccion/ajuste-absorcion-muros'
SOURCE=ROOT/'prediccion/variantes-estado-actual/B_cortinas_y_paneles.proj'
selected=json.loads((BASE/'ajuste-seleccionado.json').read_text(encoding='utf8'));delta=selected['incremento_alpha']
group_names=set(selected['grupos'])
with zipfile.ZipFile(SOURCE) as zin:files={n:zin.read(n) for n in zin.namelist()}
before=ET.fromstring(files['instance1/projet_config.xml']);root=copy.deepcopy(before)
uid=max(int(e.get('wxid','0')) for e in root.iter())+1
material=copy.deepcopy(next(u for u in root.iter('usermat') if u.get('name')=='AM_Revoque_rigido'))
material.set('name','AM_Muros_ajuste_efectivo_NO_MEDIDO');material.find('materiau').set('idmateriau','115')
material.find("property/p[@name='reference']").set('textValue','INFORME-AJUSTE-MUROS.md; ajuste inverso SPPS de P1-F1 a 1000 Hz.')
material.find("property/p[@name='description']").set('textValue',f"Coeficiente efectivo NO MEDIDO. alpha_1000={selected['alpha_1kHz']:.6f}. Solo muros generales, laterales altos y fondo alto. No identifica una propiedad real del concreto.")
for e in material.iter():
    if e.get('wxid') is not None:e.set('wxid',str(uid));uid+=1
for row in material.find('materiau').findall('p'):
    if row.get('name','').isdigit():
        p=row.find("p[@name='absorb']");p.set('value',str(min(.99,float(p.get('value'))+delta)));p.set('pr','4')
oldmaterial=next(u for u in root.iter('usermat') if u.get('name')=='AM_Revoque_rigido')
next(e for e in root.iter() if oldmaterial in list(e)).append(material)
for gr in root.iter('gr'):
    if gr.get('name') in group_names:gr.find("p[@name='idmat']").set('value','115')
for tag in ['source','recepteurp']:
    assert [ET.tostring(e) for e in root.iter(tag)]==[ET.tostring(e) for e in before.iter(tag)]
for u in before.iter('usermat'):
    assert ET.tostring(u)==ET.tostring(next(v for v in root.iter('usermat') if v.get('name')==u.get('name')))
conf=root.find('Core/spps/configuration');conf.find("p[@name='nbparticules']").set('value','300000')
conf.find("p[@name='random_seed']").set('value','20261019')
for f in root.find('Core/spps/core_conf_bfreq'):f.set('value','1' if f.get('name') in ['125','250','500','1000','2000','4000','8000'] else '0')
report=root.find('Report/folder')
for c in list(report):report.remove(c)
files={n:v for n,v in files.items() if not n.startswith('instance1/report/')}
def element(parent,tag,name,eid,**attrs):
    global uid
    e=ET.SubElement(parent,tag,{'name':name,'eid':str(eid),'wxid':str(uid),**attrs});uid+=1;return e
spps=element(report,'folder','SPPS',70,filepath='SPPS\\')
jobs=[(selected['confirmacion'],'Ajuste-1kHz-F1-1200k','F1'),('validacion-F1','Validacion-F1-300k','F1'),('validacion-F2','Validacion-F2-300k','F2')]
analyses=[]
for local,name,source in jobs:
    folder=BASE/local;analysis=json.loads((folder/'analisis.json').read_text(encoding='utf8'))
    # EDT debe empezar en la primera llegada, sin el tramo de propagación en silencio.
    raw=json.loads((folder/'resultados-lineales.json').read_text(encoding='utf8'))
    for row in analysis['resultados']:
        e=np.array(raw['receptores'][row['receptor']][str(row['frecuencia_Hz'])+' Hz'])
        db=10*np.log10(np.maximum(np.cumsum(e[::-1])[::-1]/e.sum(),1e-300))
        a=int(np.flatnonzero(e>0)[0]);b=int(np.flatnonzero(db<=-10)[0])
        t=np.arange(a,b)/1000;y=db[a:b]
        row['EDT_s']=float(-60/np.polyfit(t,y,1)[0]);row['EDT_r2']=float(np.corrcoef(t,y)[0,1]**2)
    analysis['EDT_metodo']='Ajuste desde primera llegada no nula hasta -10 dB de Schroeder; excluye silencio de propagación.'
    (folder/'analisis.json').write_text(json.dumps(analysis,indent=2,ensure_ascii=False),encoding='utf8')
    analyses.append(analysis)
    prefix='instance1/report/SPPS/'+name+'/'
    node=element(spps,'folder',name,70,filepath=name+'\\')
    def walk(path,parent,rel=''):
        for p in sorted(path.iterdir()):
            if p.is_dir():walk(p,element(parent,'folder',p.name,70,filepath=p.name+'\\'),rel+p.name+'/')
            elif p.suffix in ['.recp','.gabe','.recps','.gap','.rpi','.csbin','.xml']:
                eid={'.recp':74,'.gabe':73,'.recps':110,'.gap':81,'.csbin':75}.get(p.suffix,82)
                element(parent,'arrayfile' if eid!=82 else 'unk',p.stem,eid,filepath=p.name)
                files[prefix+rel+p.name]=p.read_bytes()
    walk(folder,node)
    for filename in ['mesh.cbin','tetramesh.mbin']:files[prefix+filename]=(BASE/filename).read_bytes()
    config=ET.fromstring(files[prefix+'config.xml']);config.find('simulation').set('modelName','mesh.cbin');config.find('simulation').set('tetrameshFileName','tetramesh.mbin')
    files[prefix+'config.xml']=ET.tostring(config,encoding='utf-8',xml_declaration=True)
    snap=copy.deepcopy(root)
    for s in snap.iter('source'):s.find("prop/p[@name='enable']").set('value','1' if s.get('name')==source else '0')
    snap.find("Core/spps/configuration/p[@name='nbparticules']").set('value',str(analysis['particulas_por_banda']))
    for f in snap.find('Core/spps/core_conf_bfreq'):f.set('value','1' if int(f.get('name')) in analysis['bandas_Hz'] else '0')
    files[prefix+'projet_config.xml']=ET.tostring(snap,encoding='utf-8',xml_declaration=True)
    element(node,'unk','projet_config',82,filepath='projet_config.xml')
files['instance1/projet_config.xml']=ET.tostring(root,encoding='utf-8',xml_declaration=True)
project=BASE/'D_muros_ajuste_1kHz.proj'
with zipfile.ZipFile(project,'w',compression=zipfile.ZIP_DEFLATED) as z:
    for n,v in files.items():z.writestr(n,v)
with zipfile.ZipFile(project) as z:
    assert z.testzip() is None
    with zipfile.ZipFile(SOURCE) as original:
        assert z.read('instance1/sceneMesh.bin')==original.read('instance1/sceneMesh.bin')
        for n in original.namelist():
            if n.endswith('.finfo'):assert z.read(n)==original.read(n)
    r=ET.fromstring(z.read('instance1/projet_config.xml'))
    assert {g.get('name') for g in r.iter('gr') if g.find("p[@name='idmat']").get('value')=='115'}==group_names
rew=json.loads((ROOT/'prediccion/resultados-convergencia-1kHz/auditoria-REW-RT.json').read_text(encoding='utf8'))['datos']
comparison=[]
for a in analyses[1:]:
    for row in a['resultados']:
        for ref in rew:
            if ref['id']==a['fuente']+'-'+row['receptor'] and ref['frecuencia_Hz']==row['frecuencia_Hz'] and not ref['excluir_duplicado']:
                if ref['T20_s']>0 and abs(ref['r_T20'])>=.99:
                    comparison.append({'fuente':a['fuente'],'receptor':row['receptor'],'frecuencia_Hz':row['frecuencia_Hz'],'metodo':ref['metodo'],
                        'T20_sim_s':row['T20_s'],'T20_REW_s':ref['T20_s'],'error_s':row['T20_s']-ref['T20_s'],
                        'usado_en_ajuste':a['fuente']=='F1' and row['receptor']=='P1' and row['frecuencia_Hz']==1000})
(BASE/'comparacion-REW.json').write_text(json.dumps(comparison,indent=2,ensure_ascii=False),encoding='utf8')
lines=['# Ajuste efectivo de absorción de paredes','',
       'Se toma B (cortinas de audiencia solo junto al escenario). Se mantiene exactamente su geometría y se aumenta únicamente la absorción de los grupos 05_muros, 10_laterales_altos y 11_fondo_alto. Cielos, pilares, paneles, butacas, cortinas, piso y dispersión conservan sus valores.','',
       '**Es un ajuste inverso efectivo: no identifica la absorción real del concreto ni demuestra por sí solo que el modelo esté calibrado.**','',
       f"Objetivo: T20 de P1–F1 en el tercio de octava de 1000 Hz = 1,70 s, con tolerancia de ±0,05 s. Resultado de confirmación con 1.200.000 partículas: {selected['T20_P1_F1_confirmado_s']:.3f} s.",
       f"Absorción efectiva a 1 kHz: α={selected['alpha_1kHz']:.5f}, frente a α=0,03 inicial. Incremento aplicado: {delta:.5f}.",'',
       '## Curva fijada antes de validar otras frecuencias','',
       'Se añade ese mismo incremento a la curva original, con límite α=0,99. Las otras bandas no se reajustan para acercarlas a REW. No se impone 1,7 s a todo el espectro.','',
       '| Frecuencia (Hz) | α original | α efectivo |','|---|---:|---:|']
confirmed_p1=next(r for r in analyses[0]['resultados'] if r['receptor']=='P1' and r['frecuencia_Hz']==1000)
lines[lines.index('## Curva fijada antes de validar otras frecuencias'):lines.index('## Curva fijada antes de validar otras frecuencias')]=[
    f"En la misma confirmación, T30 de P1–F1 es {confirmed_p1['T30_s']:.3f} s y EDT {confirmed_p1['EDT_s']:.3f} s. R² del ajuste T20={confirmed_p1['T20_r2']:.5f}; R² del ajuste T30={confirmed_p1['T30_r2']:.5f}. Estos parámetros no fueron forzados al objetivo de T20.",'']
for f,alpha0 in zip([125,250,500,1000,2000,4000],[.013,.015,.02,.03,.04,.05]):lines.append(f'| {f} | {alpha0:.3f} | {min(.99,alpha0+delta):.5f} |')
lines+=['| 8000 | 0.050 (extrapolado) | %.5f |'%min(.99,.05+delta),'',
        '## Búsqueda ejecutada','',
        '| Ejecución | Partículas | α a 1 kHz | T20 P1–F1 (s) |','|---|---:|---:|---:|']
for h in json.loads((BASE/'busqueda.json').read_text()):lines.append(f"| {h['carpeta']} | {h['particulas']} | {h['alpha_1kHz']:.5f} | {h['T20_P1_s']:.3f} |")
lines+=['','## Validación por frecuencia','',
        'Medias emparejadas: cada promedio simulado usa exactamente los receptores con referencia REW aceptada. Se excluyen duplicados de globo y ajustes REW con |r|<0,99. Las filas pueden tener distinto número de puntos. La prueba de P1–F1 a 1 kHz fue usada para ajustar, y no es una validación independiente.','',
        '| Fuente | Hz | Referencia | n | T20 sim. (s) | T20 REW (s) | Error medio (s) |','|---|---:|---|---:|---:|---:|---:|']
for source in ['F1','F2']:
    for freq in [125,250,500,1000,2000,4000,8000]:
        for method in ['Globo','Sweep']:
            rr=[r for r in comparison if r['fuente']==source and r['frecuencia_Hz']==freq and r['metodo']==method]
            if rr:lines.append(f"| {source} | {freq} | {method} | {len(rr)} | {np.mean([r['T20_sim_s'] for r in rr]):.3f} | {np.mean([r['T20_REW_s'] for r in rr]):.3f} | {np.mean([r['error_s'] for r in rr]):+.3f} |")
heldout=[r for r in comparison if not r['usado_en_ajuste']]
diagnostic={'objetivo_excluido':True,'comparaciones_fuera_del_objetivo':len(heldout),
    'error_absoluto_medio_s':float(np.mean([abs(r['error_s']) for r in heldout])),
    'RMSE_s':float(np.sqrt(np.mean([r['error_s']**2 for r in heldout]))),
    'nota':'Comparaciones correlacionadas por fuente/receptor/método; resumen descriptivo, no incertidumbre estadística ni criterio normativo.'}
(BASE/'diagnostico-validacion.json').write_text(json.dumps(diagnostic,indent=2,ensure_ascii=False),encoding='utf8')
lines+=['',f"Fuera del punto y banda usados para ajustar, el error absoluto medio frente a las referencias aceptadas es {diagnostic['error_absoluto_medio_s']:.3f} s y el RMSE {diagnostic['RMSE_s']:.3f} s. Son resúmenes descriptivos de comparaciones correlacionadas, no una certificación de exactitud."]
lines+=['','## Interpretación de la comprobación','',
    'A 1 kHz, las medias simuladas emparejadas con globos son 1,702 s para F1 y 1,733 s para F2, frente a 1,714 y 1,720 s en REW. El ajuste del punto objetivo también se aproxima a las medias de esa banda.',
    'La curva no se generaliza a todo el espectro: a 250 Hz se obtienen aproximadamente 2,47–2,53 s frente a 1,45–1,58 s medidos; a 500 Hz persiste exceso de reverberación. A 2–4 kHz, por el contrario, el incremento uniforme produce tiempos menores que las referencias.',
    'Esto no justifica elegir el valor efectivo como coeficiente del concreto. La siguiente hipótesis debe distinguir el comportamiento por frecuencia y las construcciones que el modelo está representando de forma equivalente; no basta un único aumento de absorción en toda la curva.',
    'A 125 Hz, algunas regresiones simuladas T20 tienen R²≈0,94–0,96 y son claramente menos lineales. Sus cifras se conservan como diagnóstico, pero necesitan más partículas y revisión de las curvas y duración antes de considerarlas una estimación precisa de RT. El RMSE global incluye esas cifras y queda muy influido por ellas. A 8 kHz también debe recordarse la extrapolación de materiales y la sensibilidad ambiental.']
lines+=['','## Verificación espacial a 1 kHz','',
        '| Fuente | Receptor | T20 (s) | T30 (s) | EDT (s) |','|---|---|---:|---:|---:|']
for a in analyses[1:]:
    for r in a['resultados']:
        if r['frecuencia_Hz']==1000:lines.append(f"| {a['fuente']} | {r['receptor']} | {r['T20_s']:.3f} | {r['T30_s']:.3f} | {r['EDT_s']:.3f} |")
maxloss=max(100*s[5]/s[-1] for a in analyses for s in a['estadisticas'][1:])
lines+=['','## Alcance y archivos','',
        f"Pérdida máxima por mallado: {maxloss:.4f} %. Geometría nativa y tetraedros conservados. Solo 195 caras de muro reciben el nuevo identificador de material. Las validaciones espectrales usan 300.000 partículas por banda; la confirmación del ajuste usa 1.200.000.",
        'Abrir D_muros_ajuste_1kHz.proj. Incluye el nuevo material AM_Muros_ajuste_efectivo_NO_MEDIDO y los resultados de confirmación y validación. La escena, fuentes y receptores conservan la configuración de B. La estructura ZIP/XML y las referencias se verificaron; no se abrió la interfaz gráfica.',
        'La curva nueva puede compensar errores de otros elementos. Si exige absorción elevada, no debe explicarse solo por una textura rugosa. Una coincidencia en el punto objetivo no garantiza EDT, C80 o estructura de ecos correctos.',
        'La búsqueda con 100.000 partículas mostró variación y respuestas no monótonas entre algunos ensayos; se utilizó únicamente para acotar el parámetro. El objetivo se confirmó con 1.200.000 partículas. Las validaciones con 300.000 pueden diferir en el punto objetivo y requieren mayor convergencia antes de interpretar diferencias pequeñas.',
        'Los coeficientes extremos de 8 kHz siguen siendo una extrapolación de la curva inicial. Faltan temperatura/humedad medidas y directividad del altavoz de ensayo. No utilizar el nivel absoluto de estas simulaciones para dimensionar el refuerzo sonoro.','']
(BASE/'INFORME-AJUSTE-MUROS.md').write_text('\n'.join(lines),encoding='utf8')
fig,axes=plt.subplots(1,2,figsize=(12,4.8),sharey=True)
for ax,source in zip(axes,['F1','F2']):
    for method,color in [('Globo','#b46d30'),('Sweep','#668243')]:
        ff=[];sim=[];real=[]
        for freq in [125,250,500,1000,2000,4000,8000]:
            rr=[r for r in comparison if r['fuente']==source and r['frecuencia_Hz']==freq and r['metodo']==method]
            if rr:ff.append(freq);sim.append(np.mean([r['T20_sim_s'] for r in rr]));real.append(np.mean([r['T20_REW_s'] for r in rr]))
        ax.plot(ff,real,'o-',color=color,label='REW '+method);ax.plot(ff,sim,'s--',color=color,label='Simulación, mismos puntos')
    ax.set(xscale='log',xticks=[125,250,500,1000,2000,4000,8000],xticklabels=[125,250,500,1000,2000,4000,8000],xlabel='Centro del tercio de octava (Hz)',title=source)
    ax.xaxis.set_minor_formatter(NullFormatter());ax.grid(alpha=.2);ax.legend(fontsize=8)
axes[0].set_ylabel('T20 medio (s), estimación de RT60')
fig.suptitle('Paredes: ajuste a 1,7 s en P1–F1 a 1 kHz; otras bandas sin reajustar')
fig.text(.5,.012,'125 Hz: algunas curvas simuladas tienen menor linealidad; cifras de diagnóstico, pendientes de mayor convergencia.',ha='center',fontsize=8)
fig.tight_layout(rect=(0,.04,1,1));fig.savefig(BASE/'validacion-espectral.png',dpi=170);plt.close(fig)
print('Proyecto y análisis creados:',project)
print('Alpha 1kHz',selected['alpha_1kHz'],'T20 confirmado',selected['T20_P1_F1_confirmado_s'])
