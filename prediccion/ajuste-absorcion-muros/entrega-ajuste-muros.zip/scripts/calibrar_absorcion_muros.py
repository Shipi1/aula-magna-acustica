"""Búsqueda efectiva sobre paredes de B y validación espectral sin reajuste."""
from pathlib import Path
import sys,json,copy,subprocess,shutil,time,hashlib,concurrent.futures
import xml.etree.ElementTree as ET
import numpy as np
ROOT=Path(__file__).resolve().parents[2];SCRIPTS=Path(__file__).resolve().parent
BASE=ROOT/'prediccion/ajuste-absorcion-muros';BASE.mkdir(exist_ok=True)
SOURCE=ROOT/'prediccion/variantes-estado-actual/B_cortinas_y_paneles'
NATIVE='C:/Program Files/I-SIMPA/python.exe';EXE='C:/Program Files/I-SIMPA/core/spps/spps.exe'
subprocess.run([NATIVE,str(SCRIPTS/'worker_ajuste_muros.py'),'mesh'],check=True)
shutil.copy2(SOURCE/'tetramesh.mbin',BASE/'tetramesh.mbin')
template=ET.parse(SOURCE/'calculo-F1/config.xml').getroot()
history=[]

def metrics(data):
    rows=[]
    for name,bands in data['receptores'].items():
        for band,values in bands.items():
            e=np.array(values);db=10*np.log10(np.maximum(np.cumsum(e[::-1])[::-1]/e.sum(),1e-300))
            row={'receptor':name,'frecuencia_Hz':int(band.split()[0])}
            for key,lo,hi in [('T20',-5,-25),('T30',-5,-35),('EDT',0,-10)]:
                ii=np.flatnonzero(db<=lo);jj=np.flatnonzero(db<=hi);assert len(ii) and len(jj)
                a,b=int(ii[0]),int(jj[0])
                if key=='EDT':a=int(np.flatnonzero(e>0)[0])
                assert b>a+2
                t=np.arange(a,b)/1000;y=db[a:b];slope,intercept=np.polyfit(t,y,1)
                row[key+'_s']=float(-60/slope);row[key+'_r2']=float(np.corrcoef(t,y)[0,1]**2)
            row['energia_ultimo_segundo_pct']=float(100*e[3000:].sum()/e.sum())
            rows.append(row)
    return rows

def run(alpha,particles,label,bands=(1000,),source='F1'):
    out=BASE/label;out.mkdir(exist_ok=False)
    root=copy.deepcopy(template);root.set('workingdirectory',str(out)+'\\')
    sim=root.find('simulation');sim.set('nbparticules',str(particles));sim.set('random_seed','20261019')
    sim.set('modelName','..\\mesh.cbin');sim.set('tetrameshFileName','..\\tetramesh.mbin')
    for b in sim.find('freq_enum'):b.set('docalc','1' if int(b.get('freq')) in bands else '0')
    mat=copy.deepcopy(next(m for m in root.find('surface_absorption_enum') if m.get('id')=='107'));mat.set('id','115')
    # Mismo incremento aditivo en todas las bandas, fijado únicamente con 1 kHz.
    for b in mat:b.set('absorb',str(min(.99,float(b.get('absorb'))+alpha-.03)))
    root.find('surface_absorption_enum').append(mat)
    if source=='F2':
        s=root.find('sources/source');s.set('name','F2');s.set('id','1606')
        for key,val in zip(['x','y','z'],[5.60,4.72,1.5]):s.set(key,str(val))
    ET.ElementTree(root).write(out/'config.xml',encoding='utf-8',xml_declaration=True)
    start=time.monotonic();print('Calculando',label,'alpha1k=',round(alpha,5),'N=',particles,flush=True)
    with (out/'spps.log').open('w',encoding='utf8') as log:
        r=subprocess.run([EXE,str(out/'config.xml')],stdout=log,stderr=subprocess.STDOUT)
    assert r.returncode==0
    assert all((out/'Punctual receivers'/('P'+str(i))/'Sound level.recp').exists() for i in range(1,10))
    subprocess.run([NATIVE,str(SCRIPTS/'worker_ajuste_muros.py'),'read',str(out)],check=True)
    raw=json.loads((out/'resultados-lineales.json').read_text(encoding='utf8'));rows=metrics(raw)
    p1=next(r for r in rows if r['receptor']=='P1' and r['frecuencia_Hz']==1000)
    result={'carpeta':label,'fuente':source,'alpha_1kHz':alpha,'incremento_alpha':alpha-.03,'particulas_por_banda':particles,
       'bandas_Hz':list(bands),'duracion_calculo_s':time.monotonic()-start,'resultados':rows,'estadisticas':raw['estadisticas']}
    (out/'analisis.json').write_text(json.dumps(result,indent=2,ensure_ascii=False),encoding='utf8')
    print('Terminado',label,'T20 P1=',round(p1['T20_s'],4),'T30=',round(p1['T30_s'],4),flush=True)
    return p1['T20_s'],result

def trial(a,n,label):
    rt,result=run(a,n,label);history.append({'alpha_1kHz':a,'T20_P1_s':rt,'particulas':n,'carpeta':label})
    (BASE/'busqueda.json').write_text(json.dumps(history,indent=2),encoding='utf8')
    return rt

# Búsqueda acotada: no se ajustan receptores ni frecuencias de validación.
low=.03;high=.30
ylo=trial(low,100000,'busqueda-00-base')
yhi=trial(high,100000,'busqueda-01-superior')
index=2
while yhi>1.7 and high<.95:
    low,ylo=high,yhi;high=min(.95,high+.25)
    yhi=trial(high,100000,'busqueda-%02d-superior'%index);index+=1
assert ylo>=1.7>=yhi,'No se obtuvo un intervalo que contenga el objetivo con paredes pasivas.'
for k in range(4):
    alpha=low+(high-low)*(ylo-1.7)/(ylo-yhi)
    alpha=float(np.clip(alpha,low+.1*(high-low),high-.1*(high-low)))
    y=trial(alpha,100000,'busqueda-%02d-interpolada'%index);index+=1
    if abs(y-1.7)<.035:break
    if y>1.7:low,ylo=alpha,y
    else:high,yhi=alpha,y
best=min(history,key=lambda h:abs(h['T20_P1_s']-1.7));alpha=best['alpha_1kHz']
# Comprobar con mayor número de partículas y ajustar si supera tolerancia de 0,05 s.
y=trial(alpha,1200000,'confirmacion-00')
for k in range(2):
    if abs(y-1.7)<=.05:break
    # Ajuste local basado en la pendiente de la búsqueda; nueva confirmación completa.
    samples=sorted(history,key=lambda h:h['alpha_1kHz'])
    aa=np.array([h['alpha_1kHz'] for h in samples if h['particulas']==100000]);tt=np.array([h['T20_P1_s'] for h in samples if h['particulas']==100000])
    slope=np.polyfit(aa,tt,1)[0];assert slope<0
    alpha=float(np.clip(alpha+(1.7-y)/slope,.03,.95))
    y=trial(alpha,1200000,'confirmacion-%02d'%(k+1))
assert abs(y-1.7)<=.05,'No se alcanzó tolerancia: conservar resultados y revisar la búsqueda.'
selected={'alpha_1kHz':alpha,'incremento_alpha':alpha-.03,'T20_P1_F1_confirmado_s':y,'objetivo_s':1.7,'tolerancia_s':.05,
          'confirmacion':history[-1]['carpeta'],'grupos':['05_muros','10_laterales_altos','11_fondo_alto'],
          'no_modificados':['cielos','pilares','frente de balcón','embocadura','antepecho','paneles de escenario','butacas','cortinas','piso'],
          'ley_frecuencias':'alpha_B(f) + incremento_alpha, limitado a 0.99. No se reajustan otras bandas.',
          'estado':'Ajuste inverso efectivo a P1-F1 a 1 kHz; no propiedad medida del concreto ni calibración global.'}
(BASE/'ajuste-seleccionado.json').write_text(json.dumps(selected,indent=2,ensure_ascii=False),encoding='utf8')
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    jobs=[pool.submit(run,alpha,300000,'validacion-'+source,(125,250,500,1000,2000,4000,8000),source) for source in ['F1','F2']]
    for job in jobs:job.result()
print('Búsqueda y validación completadas.',flush=True)
