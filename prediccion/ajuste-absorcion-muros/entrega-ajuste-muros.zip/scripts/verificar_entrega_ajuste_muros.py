"""Audita que el único cambio físico respecto de B sea la absorción de tres grupos."""
from pathlib import Path
import json,zipfile,xml.etree.ElementTree as ET,hashlib
ROOT=Path(__file__).resolve().parents[2];BASE=ROOT/'prediccion/ajuste-absorcion-muros'
ref=json.loads((BASE/'referencia-original.json').read_text(encoding='utf8'))
source=Path(ref['proyecto_base']);assert hashlib.sha256(source.read_bytes()).hexdigest()==ref['sha256_base']
selected=json.loads((BASE/'ajuste-seleccionado.json').read_text(encoding='utf8'))
project=BASE/'D_muros_ajuste_1kHz.proj'
with zipfile.ZipFile(source) as a,zipfile.ZipFile(project) as b:
    assert b.testzip() is None
    old=ET.fromstring(a.read('instance1/projet_config.xml'));new=ET.fromstring(b.read('instance1/projet_config.xml'))
    assert a.read('instance1/sceneMesh.bin')==b.read('instance1/sceneMesh.bin')
    for n in a.namelist():
        if n.endswith('.finfo'):assert a.read(n)==b.read(n)
    for tag in ['source','recepteurp']:
        assert [ET.tostring(e) for e in old.iter(tag)]==[ET.tostring(e) for e in new.iter(tag)]
    oo={e.get('name'):e for e in old.iter('gr')};nn={e.get('name'):e for e in new.iter('gr')}
    assert oo.keys()==nn.keys()
    for name,e in oo.items():
        x=e.find("p[@name='idmat']").get('value');y=nn[name].find("p[@name='idmat']").get('value')
        assert y==('115' if name in selected['grupos'] else x)
    prev=next(u for u in old.iter('usermat') if u.get('name')=='AM_Revoque_rigido').find('materiau')
    cur=next(u for u in new.iter('usermat') if u.get('name')=='AM_Muros_ajuste_efectivo_NO_MEDIDO').find('materiau')
    oldrows={e.get('name'):e for e in prev if e.get('name','').isdigit()}
    count=0
    for row in cur:
        if row.get('name','').isdigit():
            expected=min(.99,float(oldrows[row.get('name')].find("p[@name='absorb']").get('value'))+selected['incremento_alpha'])
            assert abs(float(row.find("p[@name='absorb']").get('value'))-expected)<1e-12
            for key in ['diffusion','transmission']:
                assert row.find("p[@name='%s']"%key).get('value')==oldrows[row.get('name')].find("p[@name='%s']"%key).get('value')
            count+=1
    assert count==27
confirmed=json.loads((BASE/selected['confirmacion']/'analisis.json').read_text(encoding='utf8'))
p1=next(r for r in confirmed['resultados'] if r['receptor']=='P1' and r['frecuencia_Hz']==1000)
assert abs(p1['T20_s']-1.7)<=.05 and confirmed['particulas_por_banda']==1200000
for source_name in ['F1','F2']:
    v=json.loads((BASE/('validacion-'+source_name)/'analisis.json').read_text(encoding='utf8'))
    assert len(v['resultados'])==63 and v['bandas_Hz']==[125,250,500,1000,2000,4000,8000]
    assert v['alpha_1kHz']==selected['alpha_1kHz']
result={'original_B_intacto':True,'escena_y_referencias_de_caras_identicas':True,'fuentes_y_receptores_conservados':True,
        'cambio_fisico':'Solo absorción en 05_muros, 10_laterales_altos, 11_fondo_alto; dispersión conservada.',
        'bandas_material_verificadas':count,'T20_P1_F1_confirmado_s':p1['T20_s'],'T30_P1_F1_confirmado_s':p1['T30_s'],
        'confirmacion_particulas':1200000,'validacion_fuentes':2,'validacion_bandas_por_fuente':7,'validacion_receptores':9,
        'sha256_proyecto':hashlib.sha256(project.read_bytes()).hexdigest(),'interfaz_grafica':'No comprobada; cálculos ejecutados con SPPS instalado.'}
(BASE/'verificacion-final.json').write_text(json.dumps(result,indent=2,ensure_ascii=False),encoding='utf8')
with zipfile.ZipFile(BASE/'entrega-ajuste-muros.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
    for p in BASE.iterdir():
        if p.is_file() and p.suffix in ['.md','.json','.png','.proj','.cbin','.mbin']:z.write(p,p.name)
    for name in [selected['confirmacion'],'validacion-F1','validacion-F2']:
        for p in (BASE/name).iterdir():
            if p.is_file() and p.suffix in ['.json','.xml']:z.write(p,str(p.relative_to(BASE)))
    for name in ['calibrar_absorcion_muros.py','worker_ajuste_muros.py','entregar_ajuste_muros.py','verificar_entrega_ajuste_muros.py']:
        p=ROOT/'prediccion/configuracion'/name;z.write(p,'scripts/'+name)
print(json.dumps(result,indent=2,ensure_ascii=False))
